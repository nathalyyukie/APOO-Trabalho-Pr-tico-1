import java.util.Scanner;

public class ParOuImparLoop {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("=== Identificador de Par ou Ímpar ===");
        System.out.println("Digite números inteiros para verificar.");
        System.out.println("Digite 'S' para encerrar o programa.");

        while (true) {
            System.out.print("Digite um número inteiro (ou 'S' para sair): ");
            String entrada = scanner.nextLine().trim().toUpperCase();

            // Se o usuário digitar "S", encerra o programa
            if (entrada.equals("S")) {
                break;
            }

            // Tenta converter a entrada para número
            try {
                int numero = Integer.parseInt(entrada);

                if (numero % 2 == 0) {
                    System.out.println(numero + " é par.");
                } else {
                    System.out.println(numero + " é ímpar.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Entrada inválida! Digite apenas números inteiros ou 'S' para sair.");
            }

            System.out.println(); // linha em branco para organizar a saída
        }

        scanner.close();
        System.out.println("Programa encerrado!");
    }
}