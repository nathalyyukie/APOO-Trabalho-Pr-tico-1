public class MaiorNumero {
    public static void main(String[] args) {
        // Exemplo de array de inteiros
        int[] numeros = {12, 45, 7, 89, 23, 150, 250, 3};

        // Assume que o primeiro elemento é o maior inicialmente
        int maior = numeros[0];

        // Percorre o array comparando cada elemento
        for (int i = 1; i < numeros.length; i++) {
            if (numeros[i] > maior) {
                maior = numeros[i];
            }
        }

        // Exibe o resultado
        System.out.println("O maior número no array é: " + maior);
    }
}