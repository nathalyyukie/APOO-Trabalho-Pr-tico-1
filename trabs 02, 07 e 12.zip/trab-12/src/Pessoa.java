import java.util.*;

// Classe base
public class Pessoa {
    private String nome;
    private int idade;

    public Pessoa(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
    }

    public String getNome() {
        return nome;
    }

    public int getIdade() {
        return idade;
    }

    public void exibirInfo() {
        System.out.println("Nome: " + nome);
        System.out.println("Idade: " + idade);
    }
}

class Aluno extends Pessoa {
    public Aluno(String nome, int idade) {
        super(nome, idade);
    }

    @Override
    public void exibirInfo() {
        super.exibirInfo();
    }
}

class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Aluno> alunos = new ArrayList<>();
        int opcao = -1;

        System.out.println("Bem-vindo ao Sistema de Matrícula!");

        while (opcao != 0) {
            System.out.println("\n=== Menu ===");
            System.out.println("1. Adicionar Aluno");
            System.out.println("2. Listar Alunos");
            System.out.println("3. Remover Aluno");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opção: ");

            String input = scanner.nextLine();
            try {
                opcao = Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("Por favor selecione uma das alternativas");
                continue;
            }

            switch (opcao) {
                case 1:
                    System.out.print("Digite o nome do aluno: ");
                    String nome = scanner.nextLine();
                    System.out.print("Digite a idade do aluno: ");
                    input = scanner.nextLine();
                    try {
                        int idade = Integer.parseInt(input);
                        Aluno aluno = new Aluno(nome, idade);
                        alunos.add(aluno);
                        System.out.println("Aluno '" + nome + "' adicionado com sucesso!");
                    } catch (NumberFormatException e) {
                        System.out.println("Idade deve ser um numero valido!");
                    }
                    break;
                case 2:
                    if (alunos.isEmpty()) {
                        System.out.println("Nenhum aluno cadastrado.");
                    } else {
                        System.out.println("\n=== Lista de Alunos ===");
                        for (int i = 0; i < alunos.size(); i++) {
                            System.out.print((i + 1) + ". ");
                            alunos.get(i).exibirInfo();
                            System.out.println("-------------------");
                        }
                    }
                    break;
                case 3:
                    if (alunos.isEmpty()) {
                        System.out.println("Nenhum aluno para remover.");
                    } else {
                        System.out.println("\n=== Alunos para Remover ===");
                        for (int i = 0; i < alunos.size(); i++) {
                            System.out.print((i + 1) + ". ");
                            alunos.get(i).exibirInfo();
                        }
                        System.out.print("Digite o numero do aluno a remover: ");
                        input = scanner.nextLine();
                        try {
                            int indice = Integer.parseInt(input);
                            if (indice > 0 && indice <= alunos.size()) {
                                Aluno removido = alunos.remove(indice - 1);
                                System.out.println("Aluno '" + removido.getNome() + "' removido com sucesso!");
                            } else {
                                System.out.println("Indice invalido!");
                            }
                        } catch (NumberFormatException e) {
                            System.out.println("Indice deve ser um numero valido!");
                        }
                    }
                    break;
                case 0:
                    System.out.println("Obrigado por usar o Sistema de Matrícula. Até logo!");
                    break;
                default:
                    System.out.println("Opção inválida! Tente novamente.");
            }
        }

        scanner.close();
    }
}

